#-*- coding:utf-8 -*-
'''
Provides connection to ATAG One Thermostat REST API
'''
