#-*- coding:utf-8 -*-

'''
Provides connection to ATAG One Thermostat REST API

#__version__ = '0.1.5'
__all__ = ["pytag"]

from pytag.gateway import AtagDataStore
'''

from pyatag.gateway import AtagDataStore
