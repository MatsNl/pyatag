"""Base data to initiate an AtagDataStore."""

TESTDATA = {
    "_host": "",  # atag IP
    "_port": 10000,
    "_mail": "",  # email registered in portal
    "_scan_interval": 30,
    "_interface": "en0",  # interface on which API runs
    "_sensors": [  # sensors to test, see const.py
        "temperature",
        "current_temp"
    ]
}
